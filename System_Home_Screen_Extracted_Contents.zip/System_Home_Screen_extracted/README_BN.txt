System Home Screen APK — Extracted Contents

গুরুত্বপূর্ণ:
এই ফোল্ডারটি APK থেকে সরাসরি বের করা (raw extraction) ফাইলসমূহের সংগ্রহ। এটি এখনো সম্পূর্ণ Decompiled Android Studio Project নয়।

যা পাওয়া গেছে:
- classes.dex, classes2.dex, classes3.dex: Android bytecode (এগুলো Java/Kotlin source code নয়)
- AndroidManifest.xml: binary Android manifest (এখনো readable XML-এ decode করা হয়নি)
- res/: APK resource files
- assets/: app assets
- অন্যান্য APK metadata/signature files

যা এখনো করা হয়নি:
- DEX bytecode থেকে Java source decompile
- AndroidManifest.xml ও resources.arsc decode
- Gradle build files / Android Studio project reconstruction

কারণ:
এই পরিবেশে JADX/APKTool decompiler ইনস্টল বা চালানো সম্ভব হয়নি। তাই decompiled source বলে ভুলভাবে উপস্থাপন করা হচ্ছে না।

পরবর্তী ধাপ:
JADX দিয়ে APK decompile করলে Java source এবং readable manifest/resources পাওয়া যাবে। JADX সাধারণত সব code নিখুঁতভাবে decompile করতে পারে না; কিছু অংশে errors থাকতে পারে।
