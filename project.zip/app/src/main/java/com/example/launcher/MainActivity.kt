package com.example.launcher

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.TargetApi
import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.KeyguardManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.*
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.content.res.Resources
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.CancellationSignal
import android.provider.ContactsContract
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import android.view.animation.DecelerateInterpolator
import java.util.Calendar
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.window.OnBackInvokedDispatcher
import java.util.concurrent.Executors
import kotlin.math.abs
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class App(val pkg: String, val label: String, val icon: Bitmap, val cat: Int = -1)

class Contact(val name: String, val number: String)
class Photo(val name: String, val uri: Uri)

/** Damped-spring curve: overshoots the target and settles, like a physical spring. */
class SpringInterpolator(private val damping: Float = 5f, private val frequency: Float = 9f) : android.view.animation.Interpolator {
    override fun getInterpolation(t: Float): Float =
        (1.0 - Math.exp((-damping * t).toDouble()) * Math.cos((frequency * t).toDouble())).toFloat()
}

/** Horizontal pager used for the widget stack: always settles on a whole page. */
class SnapScroll(ctx: Context) : HorizontalScrollView(ctx) {
    var pitch = 1
    var pages = 1
    var onPage: ((Int, Boolean) -> Unit)? = null // (page, changedByUser)
    private var startX = 0

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
    }

    private fun lastPage() = maxOf(pages - 1, 0)

    fun goTo(page: Int, smooth: Boolean) {
        val x = page.coerceIn(0, lastPage()) * pitch
        if (smooth) smoothScrollTo(x, 0) else scrollTo(x, 0)
    }

    override fun fling(velocityX: Int) {} // snapping on release replaces free flinging

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) startX = scrollX
        val r = super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            val moved = scrollX - startX
            val from = ((startX + pitch / 2) / pitch).coerceIn(0, lastPage())
            val target = if (abs(moved) > pitch / 6) (if (moved > 0) from + 1 else from - 1) else from
            val t = target.coerceIn(0, lastPage())
            goTo(t, true)
            onPage?.invoke(t, true)
        }
        return r
    }
}

/** Tiny recursive-descent calculator for the search bar: + - * / % ^ and parentheses. */
class Calc(private val s: String) {
    private var i = 0
    fun parse(): Double {
        val v = expr()
        skip()
        if (i < s.length) throw IllegalArgumentException("trailing input")
        return v
    }
    private fun skip() { while (i < s.length && s[i].isWhitespace()) i++ }
    private fun eat(c: Char): Boolean {
        skip()
        if (i < s.length && s[i] == c) { i++; return true }
        return false
    }
    private fun expr(): Double {
        var v = term()
        while (true) {
            v = if (eat('+')) v + term() else if (eat('-')) v - term() else return v
        }
    }
    private fun term(): Double {
        var v = pow()
        while (true) {
            v = if (eat('*')) v * pow() else if (eat('/')) v / pow() else if (eat('%')) v % pow() else return v
        }
    }
    private fun pow(): Double {
        val b = unary()
        return if (eat('^')) Math.pow(b, pow()) else b
    }
    private fun unary(): Double = if (eat('-')) -unary() else if (eat('+')) unary() else atom()
    private fun atom(): Double {
        if (eat('(')) {
            val v = expr()
            if (!eat(')')) throw IllegalArgumentException("missing )")
            return v
        }
        skip()
        val st = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (st == i) throw IllegalArgumentException("number expected")
        return s.substring(st, i).toDouble()
    }
}

class MainActivity : Activity() {

    private companion object {
        const val TAG = "MyLauncher"
        const val REQ_AUTH = 1001
        const val REQ_BIND = 1002
        const val REQ_CONFIG = 1003
        const val HOST_ID = 1024
        const val REQ_CONTACTS = 1004
        const val REQ_PHOTOS = 1005
        const val REQ_EXPORT = 1006
        const val REQ_IMPORT = 1007
        val FINANCE_WORDS = listOf("bank", "wallet", "bkash", "nagad", "rocket", "finance", "payment", "paypal", "invest", "crypto", "money", "upay")
        // unit -> (dimension, factor to the dimension's base unit); temperature is handled separately
        val UNITS: Map<String, Pair<String, Double>> = mapOf(
            "mm" to ("len" to 0.001), "cm" to ("len" to 0.01), "m" to ("len" to 1.0), "km" to ("len" to 1000.0),
            "in" to ("len" to 0.0254), "ft" to ("len" to 0.3048), "yd" to ("len" to 0.9144), "mi" to ("len" to 1609.344),
            "mg" to ("mass" to 0.000001), "g" to ("mass" to 0.001), "kg" to ("mass" to 1.0),
            "lb" to ("mass" to 0.45359237), "oz" to ("mass" to 0.028349523125),
            "ml" to ("vol" to 0.001), "l" to ("vol" to 1.0), "gal" to ("vol" to 3.785411784),
            "kmh" to ("spd" to 1.0), "mph" to ("spd" to 1.609344), "ms" to ("spd" to 3.6),
            "c" to ("temp" to 1.0), "f" to ("temp" to 1.0), "k" to ("temp" to 1.0)
        )
        val ALIASES = mapOf(
            "inch" to "in", "inches" to "in", "feet" to "ft", "foot" to "ft", "mile" to "mi", "miles" to "mi",
            "lbs" to "lb", "pound" to "lb", "pounds" to "lb", "kilo" to "kg", "km/h" to "kmh", "kph" to "kmh", "m/s" to "ms",
            "celsius" to "c", "fahrenheit" to "f", "kelvin" to "k", "liter" to "l", "litre" to "l", "liters" to "l", "litres" to "l"
        )
        val ACCENTS = intArrayOf(0xFF4DA3FF.toInt(), 0xFF4CD964.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF5C8A.toInt())
        val ACCENT_NAMES = intArrayOf(R.string.accent_blue, R.string.accent_green, R.string.accent_orange, R.string.accent_pink)
        // index 0 = all; 1..6 = category groups 0..5 (see groupOf); last = app library view
        val CHIPS = intArrayOf(R.string.chip_all, R.string.chip_social, R.string.chip_games, R.string.chip_media, R.string.chip_tools, R.string.chip_finance, R.string.chip_other, R.string.chip_library)
    }

    // One app tile: icon + notification badge + label (reused by drawer, frequent row and dock)
    private class Cell(val root: LinearLayout, val icon: ImageView, val badge: TextView, val label: TextView)

    private lateinit var prefs: SharedPreferences
    private lateinit var home: LinearLayout
    private lateinit var topRow: LinearLayout
    private lateinit var homeSearch: TextView
    private lateinit var hintView: TextView
    private lateinit var dockBar: LinearLayout
    private lateinit var widgetBox: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var clearBtn: TextView
    private lateinit var chipRow: LinearLayout
    private lateinit var freqBox: LinearLayout
    private lateinit var freqLabel: TextView
    private lateinit var freqRow: LinearLayout
    private lateinit var grid: GridView
    private lateinit var emptyView: TextView
    private lateinit var gd: GestureDetector
    private lateinit var awm: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetScroll: ScrollView
    private lateinit var extraBox: LinearLayout   // calculator / unit / quick-action / contact / web rows
    private lateinit var libScroll: ScrollView    // app library (auto categories)
    private lateinit var libBox: LinearLayout
    private lateinit var pill: TextView           // floating "island" pill on the home screen
    private val searcher = Executors.newSingleThreadExecutor()
    private var searchGen = 0
    private var libMode = false
    private var leftInset = 0
    private var rightInset = 0
    private var topInset = 0
    private var flashMsg: String? = null
    private var powerRegistered = false
    private var baseline: FloatArray? = null
    private var sx = 0f
    private var sy = 0f
    private var stack: SnapScroll? = null
    private var stackIds: List<Int> = emptyList()
    private var dotsRow: LinearLayout? = null
    private var blurAnim: ValueAnimator? = null
    private var blurNow = 0
    private val adapter = AppAdapter()
    private var allApps = listOf<App>()
    private var loadGen = 0 // only the newest loadApps() result is applied
    private val maxDock = 4
    private val ui = Handler(Looper.getMainLooper())
    private val loader = Executors.newSingleThreadExecutor() // one loader at a time
    private val reload = Runnable { loadApps() }
    private var loaded = false      // true once the first app list arrived
    private var bottomInset = 0     // nav/gesture bar height, used by the dock
    private var asHome = true       // false when opened from another launcher's icon
    private var category = -1       // drawer filter, -1 = all
    private var afterAuth: (() -> Unit)? = null
    private var pendingWidgetId = -1
    private var vt: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f

    // ---------- Preferences ----------
    private val cols get() = prefs.getInt("cols", 4)
    private val iconDp get() = prefs.getInt("icon", 48)
    private val win get() = prefs.getBoolean("win", false)
    private val dark get() = prefs.getBoolean("dark", true)
    private val badgesOn get() = prefs.getBoolean("badges", true)
    private val accent get() = ACCENTS[prefs.getInt("accent", 0).coerceIn(0, ACCENTS.size - 1)]
    private val iconPack: String get() = prefs.getString("iconpack", "") ?: ""
    private val hidden: Set<String> get() = prefs.getStringSet("hidden", emptySet())!!.toSet()
    private val locked: Set<String> get() = prefs.getStringSet("locked", emptySet())!!.toSet()
    private var dock: List<String>
        get() = prefs.getString("dock", "")!!.split(",").filter { it.isNotEmpty() }.distinct()
        set(v) { prefs.edit().putString("dock", v.distinct().joinToString(",")).apply() }
    private var widgetIds: List<Int>
        get() = prefs.getString("widgets", "")!!.split(",").mapNotNull { it.toIntOrNull() }
        set(v) { prefs.edit().putString("widgets", v.joinToString(",")).apply() }
    private fun launchCount(pkg: String) = prefs.getInt("n_$pkg", 0)

    // ---------- Extra look & feel options ----------
    private val sortMode get() = prefs.getInt("sort", 0)          // 0 A-Z, 1 most used, 2 newest
    private val shapeMode get() = prefs.getInt("shape", 0)        // 0 default, 1 circle, 2 rounded, 3 soft square
    private val animMode get() = prefs.getInt("anim", 0)          // 0 zoom, 1 fade, 2 none
    private val badgeDot get() = prefs.getBoolean("badgedot", false)
    private val showSearchBar get() = prefs.getBoolean("showsearch", true)
    private val rotateOn get() = prefs.getBoolean("rotate", true)
    private val simpleOn get() = prefs.getBoolean("simple", false)
    private val installTimes = HashMap<String, Long>()

    @Suppress("DEPRECATION")
    private fun installTime(pkg: String): Long = installTimes.getOrPut(pkg) {
        try { packageManager.getPackageInfo(pkg, 0).firstInstallTime } catch (e: Exception) { 0L }
    }

    private fun applyShape(v: View) {
        val mode = shapeMode
        if (mode == 0) { v.clipToOutline = false; return }
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val side = minOf(view.width, view.height).toFloat()
                val r = when (mode) { 1 -> side / 2f; 2 -> side * 0.24f; else -> side * 0.10f }
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.invalidateOutline()
    }
    private val labelsOn get() = prefs.getBoolean("labels", true)
    private val smart get() = prefs.getBoolean("smart", false)
    private val pillOn get() = prefs.getBoolean("pill", true)
    private val stackMode get() = prefs.getBoolean("stack", false)
    private val flipOn get() = prefs.getBoolean("flip", false)
    private val parallaxOn get() = prefs.getBoolean("parallax", false)
    private val contactsOn get() = prefs.getBoolean("contacts", false) &&
        checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    // ---------- Theme colours (drawer only; home keeps white text over the wallpaper) ----------
    // lower alpha when the wallpaper is blurred behind the drawer (glass look)
    private val drawerBg get() = if (dark) ((if (glassOn()) 0x99 else 0xEE) shl 24) or 0x101418
        else ((if (glassOn()) 0xB4 else 0xF2) shl 24) or 0xF6F7F9
    private val fg get() = if (dark) Color.WHITE else 0xFF111418.toInt()
    private val hintFg get() = if (dark) 0x99FFFFFF.toInt() else 0x99000000.toInt()
    private val fieldBg get() = if (dark) 0x33FFFFFF else 0x22000000

    private fun px(dp: Int) = (dp * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = px(r).toFloat() }
    private fun white(t: TextView) = t.apply { setTextColor(Color.WHITE); setShadowLayer(6f, 0f, 2f, Color.BLACK) }
    private fun themed(t: TextView) = t.apply {
        setTextColor(fg)
        if (dark) setShadowLayer(6f, 0f, 2f, Color.BLACK) else setShadowLayer(0f, 0f, 0f, 0)
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_PACKAGE_REMOVED) {
                // An app update sends REMOVED then ADDED; don't forget dock/hidden state on updates
                if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
                i.data?.schemeSpecificPart?.let { p ->
                    if (p in dock) dock = dock - p
                    if (p in hidden) prefs.edit().putStringSet("hidden", hidden - p).apply()
                    if (p in locked) prefs.edit().putStringSet("locked", locked - p).apply()
                    prefs.edit().remove("n_$p").apply()
                }
            }
            scheduleLoad()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        awm = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, HOST_ID)
        setupEdgeToEdge()
        asHome = intent.hasCategory(Intent.CATEGORY_HOME)

        // Dark scrim top and bottom so white text stays readable on bright wallpapers
        val root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x99000000.toInt(), 0x22000000, 0x22000000, 0xAA000000.toInt())
        )

        // ---------- Home ----------
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, px(48), 0, 0) }
        topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(white(TextClock(this).apply { format12Hour = "hh:mm"; format24Hour = "HH:mm"; textSize = 52f }))
        col.addView(white(TextClock(this).apply { format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"; textSize = 16f }))
        topRow.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topRow.addView(white(TextView(this).apply {
            text = "⚙"; textSize = 24f
            contentDescription = getString(R.string.settings)
            gravity = Gravity.CENTER; minWidth = px(48); minHeight = px(48)
            setOnClickListener { showSettings() }
        }))
        home.addView(topRow, LinearLayout.LayoutParams(-1, -2).apply { setMargins(px(20), 0, px(20), 0) })

        homeSearch = white(TextView(this).apply {
            text = getString(R.string.home_search); textSize = 16f
            setPadding(px(16), px(12), px(16), px(12))
            background = round(0x44FFFFFF, 24)
            setOnClickListener { openDrawer(true) }
        })
        home.addView(homeSearch, LinearLayout.LayoutParams(-1, -2).apply { setMargins(px(20), px(24), px(20), 0) })

        // Widgets live in the free space between the search bar and the dock
        widgetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        widgetScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(widgetBox, FrameLayout.LayoutParams(-1, -2))
        }
        home.addView(widgetScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        hintView = white(TextView(this).apply { text = ""; textSize = 12f; gravity = Gravity.CENTER; visibility = View.GONE })
        home.addView(hintView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(10) })
        dockBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        home.addView(dockBar, LinearLayout.LayoutParams(-1, -2))
        root.addView(home, FrameLayout.LayoutParams(-1, -1))

        // Floating pill: calls, music, timers, navigation, delivery progress, charging
        pill = TextView(this).apply {
            textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            maxWidth = px(280)
            setPadding(px(16), px(8), px(16), px(8))
            background = round(0xFF000000.toInt(), 20)
            elevation = px(6).toFloat()
            visibility = View.GONE
            setOnClickListener { openLive() }
        }
        root.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = px(28) })

        // ---------- Drawer ----------
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(drawerBg)
            setPadding(px(12), px(48), px(12), px(8))
            visibility = View.GONE
        }
        search = EditText(this).apply {
            hint = getString(R.string.search_hint)
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            setPadding(px(16), px(10), px(16), px(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) = applyFilter()
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, _, _ ->
                val first = adapter.items.firstOrNull()
                if (first != null) launch(first)
                else { val q = search.text.toString().trim(); if (q.isNotEmpty()) openWeb(q) }
                true
            }
        }
        clearBtn = TextView(this).apply {
            text = "✕"; textSize = 20f
            contentDescription = getString(R.string.cd_clear)
            gravity = Gravity.CENTER; minWidth = px(48); minHeight = px(48)
            // text in the box -> clear it; empty box -> close the drawer
            setOnClickListener { if (search.text.isNotEmpty()) search.setText("") else closeDrawer() }
        }
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        searchRow.addView(search, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(clearBtn, LinearLayout.LayoutParams(-2, -2))

        chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow, FrameLayout.LayoutParams(-2, -2))
        }

        freqLabel = TextView(this).apply { text = getString(R.string.frequent); textSize = 12f; setPadding(px(4), 0, 0, px(4)) }
        freqRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 4f }
        freqBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(freqLabel, LinearLayout.LayoutParams(-1, -2))
            addView(freqRow, LinearLayout.LayoutParams(-1, -2))
        }

        grid = GridView(this).apply {
            numColumns = cols
            verticalSpacing = px(16)
            clipToPadding = false
            setPadding(0, px(8), 0, px(8))
            selector = ColorDrawable(Color.TRANSPARENT)
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, v, p, _ -> launch(this@MainActivity.adapter.items[p], v) }
            setOnItemLongClickListener { _, _, p, _ -> showAppMenu(this@MainActivity.adapter.items[p], false); true }
        }
        emptyView = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; visibility = View.GONE }
        libBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            visibility = View.GONE
            addView(libBox, FrameLayout.LayoutParams(-1, -2))
        }
        extraBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val body = FrameLayout(this)
        body.addView(grid, FrameLayout.LayoutParams(-1, -1))
        body.addView(libScroll, FrameLayout.LayoutParams(-1, -1))
        body.addView(emptyView, FrameLayout.LayoutParams(-1, -1))

        drawer.addView(searchRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(8) })
        drawer.addView(chipScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(8) })
        drawer.addView(freqBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(8) })
        drawer.addView(extraBox, LinearLayout.LayoutParams(-1, -2))
        drawer.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // System bars / cutout / keyboard insets (needed for Android 15+ edge-to-edge)
        root.setOnApplyWindowInsetsListener { _, ins ->
            val b = insetsOf(ins)
            leftInset = b.left; rightInset = b.right; topInset = b.top
            applyHomePadding()
            val nb = navBottomOf(ins)
            if (nb != bottomInset) { bottomInset = nb; buildDock() }
            (pill.layoutParams as FrameLayout.LayoutParams).topMargin = b.top + px(4)
            pill.requestLayout()
            drawer.setPadding(b.left + px(12), b.top + px(24), b.right + px(12), b.bottom + px(8))
            ins
        }

        // Double tap on empty home space (optional "lock screen" gesture). Swipes are handled in trackSwipe().
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (prefs.getBoolean("dtlock", false) && onEmptyHome(e.rawX, e.rawY, true)) {
                    if (!LauncherAccessibilityService.lockScreen()) toast(getString(R.string.a11y_off_toast))
                    return true
                }
                return false
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, filter, Context.RECEIVER_EXPORTED)
            // Android 16+ (predictive back) no longer calls onBackPressed()
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) { handleBack() }
        } else {
            registerReceiver(pkgReceiver, filter)
        }
        restoreWidgets()
        applyTheme()
        loadApps()
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (e: Exception) { Log.w(TAG, "widget host start failed", e) }
        BadgeService.listener = { refreshBadges() }
        registerPower()
        startParallax()
        autoFlip()
        refreshBadges()
    }

    override fun onStop() {
        try { widgetHost.stopListening() } catch (e: Exception) { Log.w(TAG, "widget host stop failed", e) }
        BadgeService.listener = null
        unregisterPower()
        stopParallax()
        ui.removeCallbacks(clearFlash)
        super.onStop()
    }

    private fun applyHomePadding() {
        val pillShown = ::pill.isInitialized && pill.visibility == View.VISIBLE
        home.setPadding(leftInset, topInset + px(if (pillShown) 44 else 24), rightInset, 0)
    }

    @Suppress("DEPRECATION")
    private fun setupEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
    }

    @Suppress("DEPRECATION")
    private fun insetsOf(i: WindowInsets): Rect {
        return if (Build.VERSION.SDK_INT >= 30) {
            val t = WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime()
            i.getInsets(t).let { Rect(it.left, it.top, it.right, it.bottom) }
        } else {
            Rect(i.systemWindowInsetLeft, i.systemWindowInsetTop, i.systemWindowInsetRight, i.systemWindowInsetBottom)
        }
    }

    @Suppress("DEPRECATION")
    private fun navBottomOf(i: WindowInsets): Int =
        if (Build.VERSION.SDK_INT >= 30) i.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()).bottom
        else i.systemWindowInsetBottom

    // ---------- Touch: double tap + swipe up / swipe down ----------
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gd.onTouchEvent(ev)
        trackSwipe(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun trackSwipe(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(ev) }
                downX = ev.rawX; downY = ev.rawY
            }
            MotionEvent.ACTION_MOVE -> vt?.addMovement(ev)
            MotionEvent.ACTION_UP -> {
                val t = vt
                if (t != null) {
                    t.addMovement(ev)
                    t.computeCurrentVelocity(1000)
                    onSwipe(downX, downY, ev.rawX - downX, ev.rawY - downY, t.yVelocity)
                    t.recycle()
                    vt = null
                }
            }
            MotionEvent.ACTION_CANCEL -> { vt?.recycle(); vt = null }
        }
    }

    private fun onSwipe(x0: Float, y0: Float, dx: Float, dy: Float, vy: Float) {
        if (abs(dx) > abs(dy)) return // mostly horizontal
        if (drawer.visibility != View.VISIBLE) {
            if (-dy > px(80) && vy < -800) openDrawer(false)                                  // swipe up: all apps
            else if (dy > px(80) && vy > 800 && onEmptyHome(x0, y0, false)) expandNotifications() // swipe down: notifications
        } else if (dy > px(120) && vy > 1500 && gridAtTop()) {
            closeDrawer()                                                                      // swipe down: close drawer
        }
    }

    private fun gridAtTop() = grid.firstVisiblePosition == 0 && (grid.childCount == 0 || grid.getChildAt(0).top >= grid.paddingTop)

    private fun hits(v: View, x: Float, y: Float): Boolean {
        if (v.visibility != View.VISIBLE) return false
        val r = Rect()
        return v.getGlobalVisibleRect(r) && r.contains(x.toInt(), y.toInt())
    }

    // true when (x, y) is not on a widget (and, if includeControls, not on the clock/search/dock either)
    private fun onEmptyHome(x: Float, y: Float, includeControls: Boolean): Boolean {
        if (drawer.visibility == View.VISIBLE) return false
        val busy = ArrayList<View>()
        for (k in 0 until widgetBox.childCount) busy.add(widgetBox.getChildAt(k))
        if (includeControls) { busy.add(topRow); busy.add(homeSearch); busy.add(dockBar); busy.add(hintView) }
        return busy.none { hits(it, x, y) }
    }

    private fun expandNotifications() {
        if (LauncherAccessibilityService.openNotifications()) return
        try { // needs the EXPAND_STATUS_BAR permission; not guaranteed on every Android version/ROM
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
            Log.w(TAG, "expand notifications failed", e)
        }
    }

    override fun onDestroy() {
        loadGen++ // drop any load still in flight
        ui.removeCallbacks(reload)
        loader.shutdownNow()
        searcher.shutdownNow()
        super.onDestroy()
        unregisterReceiver(pkgReceiver)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        asHome = intent.hasCategory(Intent.CATEGORY_HOME)
        if (intent.action == Intent.ACTION_MAIN) closeDrawer() // Home button
    }

    private fun handleBack() {
        if (drawer.visibility == View.VISIBLE) closeDrawer()
        else if (!asHome) finish() // opened from another launcher: let the user leave
    }

    // Package broadcasts often come in bursts; reload once after they settle
    private fun scheduleLoad() {
        ui.removeCallbacks(reload)
        ui.postDelayed(reload, 300)
    }

    @Deprecated("Home screen stays open")
    override fun onBackPressed() = handleBack()

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_AUTH -> {
                val f = afterAuth
                afterAuth = null
                if (resultCode == RESULT_OK) f?.invoke()
            }
            REQ_BIND -> if (resultCode == RESULT_OK) configureOrAdd(pendingWidgetId) else dropPending()
            REQ_CONFIG -> if (resultCode == RESULT_OK) addWidget(pendingWidgetId) else dropPending()
            REQ_EXPORT -> if (resultCode == RESULT_OK) data?.data?.let { writeBackup(it) }
            REQ_IMPORT -> if (resultCode == RESULT_OK) data?.data?.let { readBackup(it) }
        }
    }

    // ---------- Loading: on a background thread, icons sized for the screen density ----------
    @Suppress("DEPRECATION")
    private fun queryActs(i: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) packageManager.queryIntentActivities(i, PackageManager.ResolveInfoFlags.of(0L))
        else packageManager.queryIntentActivities(i, 0)

    private fun loadApps() {
        val gen = ++loadGen
        val size = px(56).coerceIn(96, 192)
        val pack = iconPack
        loader.execute {
            try {
                val pm = packageManager
                val packRes: Resources? = if (pack.isNotEmpty()) {
                    try { pm.getResourcesForApplication(pack) } catch (e: Exception) { null }
                } else null
                val packMap = if (packRes != null) loadPackMap(packRes, pack) else emptyMap()
                val list = queryActs(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER))
                    .filter { it.activityInfo.packageName != packageName }
                    .distinctBy { it.activityInfo.packageName }
                    .map {
                        val ai = it.activityInfo
                        val icon = packIcon(packRes, pack, packMap, ai) ?: it.loadIcon(pm)
                        val cat = if (Build.VERSION.SDK_INT >= 26) ai.applicationInfo.category else -1
                        App(ai.packageName, it.loadLabel(pm).toString(), toBitmap(icon, size), cat)
                    }
                    .sortedBy { it.label.lowercase() }
                runOnUiThread {
                    if (isFinishing || isDestroyed || gen != loadGen) return@runOnUiThread
                    allApps = list; loaded = true; ensureDock(); applyPrefs()
                }
            } catch (e: Exception) {
                Log.w(TAG, "loading apps failed; keeping the previous list", e)
            }
        }
    }

    private fun toBitmap(d: Drawable, s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s); d.draw(Canvas(b))
        return b
    }

    // ---------- Icon packs (ADW / Nova style: appfilter.xml maps components to drawables) ----------
    private fun findIconPacks(): List<Pair<String, String>> {
        val seen = LinkedHashMap<String, String>()
        for (action in listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME")) {
            for (r in queryActs(Intent(action))) {
                val p = r.activityInfo.packageName
                if (p !in seen) seen[p] = r.loadLabel(packageManager).toString()
            }
        }
        return seen.map { it.key to it.value }
    }

    private fun loadPackMap(res: Resources, pack: String): Map<String, String> {
        val out = HashMap<String, String>()
        try {
            val id = res.getIdentifier("appfilter", "xml", pack)
            val parser: XmlPullParser = if (id != 0) {
                res.getXml(id)
            } else {
                val p = XmlPullParserFactory.newInstance().newPullParser()
                p.setInput(res.assets.open("appfilter.xml"), null)
                p
            }
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val dr = parser.getAttributeValue(null, "drawable")
                    // component="ComponentInfo{com.pkg/com.pkg.Activity}"
                    if (comp != null && dr != null && comp.startsWith("ComponentInfo{") && comp.endsWith("}")) {
                        out[comp.substring(14, comp.length - 1)] = dr
                    }
                }
                ev = parser.next()
            }
        } catch (e: Exception) {
            Log.w(TAG, "icon pack parse failed: $pack", e)
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun packIcon(res: Resources?, pack: String, map: Map<String, String>, ai: ActivityInfo): Drawable? {
        if (res == null) return null
        val name = map["${ai.packageName}/${ai.name}"] ?: return null
        val id = res.getIdentifier(name, "drawable", pack)
        if (id == 0) return null
        return try { res.getDrawable(id, null) } catch (e: Exception) { null }
    }

    @Suppress("DEPRECATION")
    private fun iconPackName(): String {
        val pk = iconPack
        if (pk.isEmpty()) return getString(R.string.default_label)
        return try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pk, 0)).toString() } catch (e: Exception) { pk }
    }

    private fun pickIconPack() {
        val packs = findIconPacks()
        if (packs.isEmpty()) { toast(getString(R.string.no_icon_packs)); return }
        val names = (listOf(getString(R.string.default_label)) + packs.map { it.second }).toTypedArray()
        AlertDialog.Builder(this).setTitle(getString(R.string.icon_pack))
            .setItems(names) { _, i ->
                prefs.edit().putString("iconpack", if (i == 0) "" else packs[i - 1].first).apply()
                loadApps()
            }.show()
    }

    private fun ensureDock() {
        if (prefs.contains("dock")) return
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        val have = allApps.map { it.pkg }.toSet()
        dock = intents.mapNotNull { i ->
            queryActs(i).map { it.activityInfo.packageName }.firstOrNull { it in have }
        }.distinct()
    }

    // ---------- Theme / prefs / filter ----------
    private fun applyTheme() {
        drawer.setBackgroundColor(drawerBg)
        search.setTextColor(fg)
        search.setHintTextColor(hintFg)
        search.background = round(fieldBg, 20)
        themed(clearBtn); themed(emptyView); themed(freqLabel)
        buildChips()
        applyPrefs()
    }

    private fun applyPrefs() {
        grid.numColumns = cols
        if (::homeSearch.isInitialized) homeSearch.visibility = if (showSearchBar) View.VISIBLE else View.GONE
        requestedOrientation = if (rotateOn) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        buildDock()
        applyFilter()
    }

    // 0 social, 1 game, 2 media, 3 tools, 4 finance, 5 other.
    // Uses ApplicationInfo.category (many apps don't declare one) plus name hints for finance apps.
    private fun groupOf(a: App): Int {
        val s = (a.pkg + " " + a.label).lowercase()
        if (FINANCE_WORDS.any { s.contains(it) }) return 4
        return when (a.cat) {
            4 -> 0
            0 -> 1
            1, 2, 3 -> 2
            5, 6, 7, 8 -> 3
            else -> 5
        }
    }

    private fun isNight(): Boolean {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h >= 22 || h < 6
    }

    private fun buildChips() {
        chipRow.removeAllViews()
        CHIPS.forEachIndexed { idx, nameRes ->
            val name = getString(nameRes)
            val isLib = idx == CHIPS.size - 1
            val cat = idx - 1
            val sel = if (isLib) libMode else (!libMode && cat == category)
            chipRow.addView(TextView(this).apply {
                text = name; textSize = 14f
                setTextColor(if (sel) Color.WHITE else fg)
                background = round(if (sel) accent else fieldBg, 16)
                setPadding(px(14), px(6), px(14), px(6))
                setOnClickListener {
                    if (isLib) { libMode = !libMode; category = -1 } else { libMode = false; category = cat }
                    buildChips(); applyFilter()
                }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = px(8) })
        }
    }

    private fun freqVisible() = search.text.isEmpty() && category < 0 && !libMode

    private fun applyFilter() {
        val raw = search.text.toString().trim()
        val q = raw.lowercase()
        val hid = hidden
        // "smart" mode quietly hides social apps from the default list at night (search and the Social chip still show them)
        val night = smart && isNight() && q.isEmpty() && category < 0
        val shown = allApps.filter {
            it.pkg !in hid &&
                !(night && groupOf(it) == 0) &&
                (category < 0 || groupOf(it) == category) &&
                (q.isEmpty() || it.label.lowercase().contains(q))
        }
        // names that start with the query come first
        adapter.items = when {
            q.isNotEmpty() -> shown.sortedBy { if (it.label.lowercase().startsWith(q)) 0 else 1 }
            sortMode == 1 -> shown.sortedByDescending { launchCount(it.pkg) }
            sortMode == 2 -> shown.sortedByDescending { installTime(it.pkg) }
            else -> shown
        }
        adapter.notifyDataSetChanged()
        emptyView.text = if (q.isEmpty()) getString(R.string.no_apps) else getString(R.string.no_apps_found)
        emptyView.visibility = if (loaded && adapter.items.isEmpty()) View.VISIBLE else View.GONE
        val lib = libMode && q.isEmpty()
        grid.visibility = if (lib) View.GONE else View.VISIBLE
        libScroll.visibility = if (lib) View.VISIBLE else View.GONE
        if (lib) buildLibrary(shown)
        buildFreq(freqVisible())
        buildExtras(raw)
    }

    // ---------- Predictive suggestions + frequent apps ----------
    private fun headphonesOn(): Boolean = try {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
    } catch (e: Exception) { false }

    private fun suggestions(): Pair<String, List<App>>? {
        val pool = allApps.filter { it.pkg !in hidden }
        if (headphonesOn()) {
            val music = pool.filter { it.cat == 1 }.take(4)
            if (music.isNotEmpty()) return getString(R.string.sug_headphones) to music
        }
        if (isNight()) {
            val words = listOf("book", "reader", "kindle", "news")
            val reading = pool.filter { a -> a.cat == 5 || words.any { w -> (a.pkg + a.label).lowercase().contains(w) } }.take(4)
            if (reading.isNotEmpty()) return getString(R.string.sug_night) to reading
        }
        return null
    }

    private fun buildFreq(visible: Boolean) {
        freqRow.removeAllViews()
        val hid = hidden
        val night = smart && isNight()
        val sug = if (visible && smart) suggestions() else null
        val list: List<App> = when {
            !visible -> emptyList()
            sug != null -> sug.second
            else -> allApps
                .filter { it.pkg !in hid && launchCount(it.pkg) > 0 && !(night && groupOf(it) == 0) }
                .sortedByDescending { launchCount(it.pkg) }
                .take(4)
        }
        freqLabel.text = sug?.first ?: getString(R.string.frequent)
        freqBox.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (a in list) {
            val c = newCell()
            bindCell(c, a, px(40), true)
            c.root.setOnClickListener { launch(a, it) }
            c.root.setOnLongClickListener { showAppMenu(a, false); true }
            freqRow.addView(c.root, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    // ---------- App library: every app sorted into automatic category sections ----------
    private fun buildLibrary(list: List<App>) {
        libBox.removeAllViews()
        for (g in 0 until CHIPS.size - 2) {
            val apps = list.filter { groupOf(it) == g }
            if (apps.isEmpty()) continue
            libBox.addView(themed(TextView(this).apply {
                text = "${getString(CHIPS[g + 1])}  (${apps.size})"; textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(px(4), px(12), 0, px(6))
            }))
            val gl = GridLayout(this).apply { columnCount = cols }
            for (a in apps) {
                val c = newCell()
                bindCell(c, a, px(iconDp), true)
                c.root.setOnClickListener { launch(a, it) }
                c.root.setOnLongClickListener { showAppMenu(a, false); true }
                val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
                lp.width = 0
                lp.bottomMargin = px(12)
                gl.addView(c.root, lp)
            }
            libBox.addView(gl, LinearLayout.LayoutParams(-1, -2))
        }
    }

    // ---------- Universal search: calculator, units, quick actions, contacts, web ----------
    private fun fmt(v: Double, digits: Int = 10): String {
        if (v == Math.rint(v) && abs(v) < 1e15) return v.toLong().toString()
        return java.math.BigDecimal(v).round(java.math.MathContext(digits)).stripTrailingZeros().toPlainString()
    }

    private fun calcText(q: String): String? {
        val s = q.replace('x', '*').replace('X', '*').replace('×', '*').replace('÷', '/').replace(",", "")
        if (!Regex("^[0-9+\\-*/^().%\\s]+$").matches(s)) return null
        if (!Regex("[+\\-*/^%]").containsMatchIn(s.trim().removePrefix("-"))) return null // a plain number isn't a sum
        val v = try { Calc(s).parse() } catch (e: Exception) { return null }
        if (v.isNaN() || v.isInfinite()) return null
        return fmt(v)
    }

    private fun convertText(q: String): String? {
        val m = Regex("^(-?[0-9]*\\.?[0-9]+)\\s*([a-zA-Z/°]+)\\s*(?:to|->|=)\\s*([a-zA-Z/°]+)$").find(q.trim()) ?: return null
        val v = m.groupValues[1].toDoubleOrNull() ?: return null
        fun unit(x: String): String { val u = x.lowercase().replace("°", ""); return ALIASES[u] ?: u }
        val a = unit(m.groupValues[2])
        val b = unit(m.groupValues[3])
        val ua = UNITS[a] ?: return null
        val ub = UNITS[b] ?: return null
        if (ua.first != ub.first) return null
        val r = if (ua.first == "temp") {
            val c = when (a) { "f" -> (v - 32) * 5 / 9; "k" -> v - 273.15; else -> v }
            when (b) { "f" -> c * 9 / 5 + 32; "k" -> c + 273.15; else -> c }
        } else v * ua.second / ub.second
        return "${fmt(v)} ${m.groupValues[2]} = ${fmt(r, 7)} ${m.groupValues[3]}"
    }

    // "call rahim", "text rahim", "whatsapp 0171..." -> verb to argument
    private fun parseQuick(q: String): Pair<String, String>? {
        val m = Regex("^(call|dial|text|sms|msg|whatsapp|wa)\\s+(.+)$", RegexOption.IGNORE_CASE).find(q.trim()) ?: return null
        return m.groupValues[1].lowercase() to m.groupValues[2].trim()
    }

    private fun isNumber(s: String) = Regex("^[+0-9][0-9\\s-]{3,}$").matches(s)

    private fun waInstalled() = packageManager.getLaunchIntentForPackage("com.whatsapp") != null

    private fun waNumber(n: String): String {
        val iso = try { (getSystemService(TELEPHONY_SERVICE) as TelephonyManager).simCountryIso.uppercase() } catch (e: Exception) { "" }
        val e164 = if (iso.isNotEmpty()) PhoneNumberUtils.formatNumberToE164(n, iso) else null
        return (e164 ?: n).filter { it.isDigit() }
    }

    private fun dial(n: String) = safeStart(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))))
    private fun sms(n: String) = safeStart(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))))
    private fun whatsapp(n: String) {
        if (!waInstalled()) { toast(getString(R.string.wa_missing)); return }
        safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + waNumber(n))).setPackage("com.whatsapp"))
    }
    private fun openWeb(q: String) = safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))

    private fun copyText(t: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("result", t))
        toast(getString(R.string.copied))
    }

    private fun contactDialog(c: Contact) {
        val acts = mutableListOf<Pair<String, () -> Unit>>()
        acts.add(getString(R.string.act_call) to { dial(c.number) })
        acts.add("💬  SMS" to { sms(c.number) })
        if (waInstalled()) acts.add("🟢  WhatsApp" to { whatsapp(c.number) })
        menu("${c.name}  •  ${c.number}", acts)
    }

    private fun quickRows(verb: String, c: Contact): List<Pair<String, () -> Unit>> = when (verb) {
        "call", "dial" -> listOf(getString(R.string.act_call_name, c.name) to { dial(c.number) })
        "whatsapp", "wa" -> listOf("🟢  WhatsApp ${c.name}" to { whatsapp(c.number) })
        else -> if (waInstalled())
            listOf("🟢  WhatsApp ${c.name}" to { whatsapp(c.number) }, "💬  SMS ${c.name}" to { sms(c.number) })
        else listOf("💬  SMS ${c.name}" to { sms(c.number) })
    }

    @Suppress("DEPRECATION")
    private fun queryContacts(name: String): List<Contact> {
        val out = ArrayList<Contact>()
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return out
        try {
            val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(nameCol, ContactsContract.CommonDataKinds.Phone.NUMBER),
                "$nameCol LIKE ?", arrayOf("%$name%"), "$nameCol ASC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 3) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    if (out.none { it.name == n }) out.add(Contact(n, num))
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "contact search failed", e)
        }
        return out
    }

    private fun buildExtras(q: String) {
        val gen = ++searchGen
        if (q.isEmpty()) { extraBox.visibility = View.GONE; return }
        renderExtras(q, emptyList())
        val needle = parseQuick(q)?.second ?: q
        val wantContacts = contactsOn && needle.length >= 2 && !isNumber(needle)
        val wantPhotos = galleryOn && needle.length >= 2 && !isNumber(needle)
        if (wantContacts || wantPhotos) {
            searcher.execute {
                val found = if (wantContacts) queryContacts(needle) else emptyList()
                val photos = if (wantPhotos) queryPhotos(needle) else emptyList()
                runOnUiThread {
                    if (!isFinishing && !isDestroyed && gen == searchGen && (found.isNotEmpty() || photos.isNotEmpty())) renderExtras(q, found, photos)
                }
            }
        }
    }

    private fun renderExtras(q: String, found: List<Contact>, photos: List<Photo> = emptyList()) {
        val rows = ArrayList<Pair<String, () -> Unit>>()
        calcText(q)?.let { r -> rows.add("🧮  ${q.trim()} = $r" to { copyText(r) }) }
        convertText(q)?.let { r -> rows.add("🔁  $r" to { copyText(r) }) }
        rows.addAll(toolRows(q))
        val quick = parseQuick(q)
        if (quick != null) {
            val targets = if (isNumber(quick.second)) listOf(Contact(quick.second, quick.second)) else found
            for (c in targets.take(2)) rows.addAll(quickRows(quick.first, c))
        } else {
            for (c in found.take(2)) rows.add("👤  ${c.name}  •  ${c.number}" to { contactDialog(c) })
        }
        for (p in photos.take(2)) rows.add("🖼  ${p.name}" to { openPhoto(p) })
        val web = getString(R.string.web_search, q.trim()) to { openWeb(q.trim()) }
        val shown = if (rows.size > 3) rows.take(3) + web else rows + web
        extraBox.removeAllViews()
        for ((text, act) in shown) {
            extraBox.addView(themed(TextView(this).apply {
                this.text = text; textSize = 15f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                setPadding(px(14), px(11), px(14), px(11))
                background = round(fieldBg, 12)
                setOnClickListener { act(); closeDrawer() }
            }), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(6) })
        }
        extraBox.visibility = View.VISIBLE
    }

    // ---------- App tiles with notification badge ----------
    private fun newCell(): Cell {
        val icon = ImageView(this)
        val badge = TextView(this).apply {
            textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            minWidth = px(18); minHeight = px(18)
            setPadding(px(4), 0, px(4), 0)
            background = round(0xFFE53935.toInt(), 9)
            visibility = View.GONE
        }
        val box = FrameLayout(this).apply {
            addView(icon, FrameLayout.LayoutParams(-2, -2))
            addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        }
        val label = TextView(this).apply {
            textSize = 12f; maxLines = 1; gravity = Gravity.CENTER
            setPadding(0, px(4), 0, 0)
            ellipsize = TextUtils.TruncateAt.END
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(box, LinearLayout.LayoutParams(-2, -2))
            addView(label, LinearLayout.LayoutParams(-1, -2))
            // press = shrink, release = spring back (the touch still reaches click / long-click)
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(SpringInterpolator()).start()
                }
                false
            }
        }
        return Cell(root, icon, badge, label)
    }

    private fun bindCell(c: Cell, a: App, iconPx: Int, showLabel: Boolean) {
        c.icon.layoutParams = FrameLayout.LayoutParams(iconPx, iconPx)
        c.icon.setImageBitmap(a.icon)
        applyShape(c.icon)
        val n = if (badgesOn) (BadgeService.counts[a.pkg] ?: 0) else 0
        c.badge.visibility = if (n > 0) View.VISIBLE else View.GONE
        if (n > 0) {
            if (badgeDot) { c.badge.text = ""; c.badge.minWidth = px(10); c.badge.minHeight = px(10) }
            else { c.badge.text = if (n > 9) "9+" else n.toString(); c.badge.minWidth = px(18); c.badge.minHeight = px(18) }
        }
        val label = showLabel && labelsOn // minimalist mode hides every label
        c.label.visibility = if (label) View.VISIBLE else View.GONE
        if (label) {
            themed(c.label)
            c.label.text = if (a.pkg in locked) "🔒 ${a.label}" else a.label
        }
    }

    private fun refreshBadges() {
        if (!::grid.isInitialized) return
        adapter.notifyDataSetChanged()
        buildDock()
        buildFreq(freqVisible())
        if (libMode && search.text.isEmpty()) buildLibrary(adapter.items)
        updatePill()
    }

    // ---------- Floating pill ("island"): live notifications + charging ----------
    private val clearFlash = Runnable { flashMsg = null; updatePill() }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED -> flash(getString(R.string.charging, batteryLevel()))
                Intent.ACTION_POWER_DISCONNECTED -> flash(getString(R.string.unplugged, batteryLevel()))
            }
        }
    }

    private fun registerPower() {
        if (powerRegistered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(powerReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(powerReceiver, f)
        powerRegistered = true
    }

    private fun unregisterPower() {
        if (!powerRegistered) return
        try { unregisterReceiver(powerReceiver) } catch (e: Exception) { Log.w(TAG, "power receiver", e) }
        powerRegistered = false
    }

    private fun batteryLevel(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l < 0 || sc <= 0) 0 else l * 100 / sc
    }

    private fun flash(msg: String) {
        flashMsg = msg
        ui.removeCallbacks(clearFlash)
        ui.postDelayed(clearFlash, 3500)
        updatePill()
    }

    private fun liveText(l: List<BadgeService.Live>): String {
        val f = l[0]
        val icon = when (f.category) {
            "call" -> "📞"; "transport" -> "🎵"; "progress" -> "⏳"; "navigation" -> "🧭"; "stopwatch" -> "⏱"; else -> "●"
        }
        val t = if (f.title.isNotEmpty()) f.title else f.text
        return "$icon  $t" + if (l.size > 1) "  +${l.size - 1}" else ""
    }

    private fun updatePill() {
        if (!::pill.isInitialized) return
        val live = BadgeService.live
        val msg = flashMsg ?: if (pillOn && live.isNotEmpty()) liveText(live) else null
        if (msg == null) {
            pill.visibility = View.GONE
        } else {
            val appear = pill.visibility != View.VISIBLE
            pill.text = msg
            if (appear) {
                pill.alpha = 0f; pill.scaleX = 0.6f; pill.scaleY = 0.6f
                pill.visibility = View.VISIBLE
                pill.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(SpringInterpolator()).start()
            }
        }
        applyHomePadding()
    }

    private fun openLive() {
        val l = BadgeService.live.firstOrNull() ?: return
        if (flashMsg != null) return
        try {
            l.intent?.send() ?: packageManager.getLaunchIntentForPackage(l.pkg)?.let { tryStart(it) }
        } catch (e: Exception) {
            packageManager.getLaunchIntentForPackage(l.pkg)?.let { tryStart(it) }
        }
    }

    // ---------- Parallax: tilt the phone and the layers drift at different depths ----------
    private val tiltListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val r = FloatArray(9)
            SensorManager.getRotationMatrixFromVector(r, event.values)
            val o = FloatArray(3)
            SensorManager.getOrientation(r, o)
            val b = baseline ?: floatArrayOf(o[1], o[2]).also { baseline = it }
            val ty = (o[1] - b[0]).coerceIn(-0.5f, 0.5f)
            val tx = (o[2] - b[1]).coerceIn(-0.5f, 0.5f)
            sx += (tx - sx) * 0.12f
            sy += (ty - sy) * 0.12f
            applyParallax()
        }
        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
    }

    private fun applyParallax() {
        val d = px(18).toFloat()
        topRow.translationX = -sx * d * 0.5f; topRow.translationY = -sy * d * 0.5f
        widgetScroll.translationX = -sx * d; widgetScroll.translationY = -sy * d
        if (!win) { dockBar.translationX = -sx * d * 1.6f; dockBar.translationY = -sy * d * 1.6f }
    }

    private fun startParallax() {
        if (!parallaxOn) return
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) ?: return
        baseline = null
        sm.registerListener(tiltListener, s, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun stopParallax() {
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(tiltListener)
        sx = 0f; sy = 0f
        applyParallax()
    }

    private fun toggleParallax() {
        val on = !parallaxOn
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        if (on && sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) == null) {
            toast(getString(R.string.no_parallax)); return
        }
        prefs.edit().putBoolean("parallax", on).apply()
        if (on) startParallax() else stopParallax()
    }

    // ---------- Glass blur behind the drawer (Android 12+) ----------
    private fun glassOn(): Boolean =
        prefs.getBoolean("glass", true) && Build.VERSION.SDK_INT >= 31 &&
            (getSystemService(WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled

    private fun animateBlur(to: Int) {
        if (Build.VERSION.SDK_INT < 31) return
        val target = if (glassOn()) to else 0
        blurAnim?.cancel()
        val a = ValueAnimator.ofInt(blurNow, target).setDuration(220)
        a.addUpdateListener {
            blurNow = it.animatedValue as Int
            try { window.setBackgroundBlurRadius(blurNow) } catch (e: Exception) { Log.w(TAG, "blur failed", e) }
        }
        blurAnim = a
        a.start()
    }

    // ---------- Dock / Windows-style taskbar ----------
    private fun dockIcon(a: App, dp: Int): View {
        val c = newCell()
        bindCell(c, a, px(dp), false)
        return c.root.apply {
            gravity = Gravity.CENTER
            contentDescription = a.label
            setOnClickListener { launch(a, it) }
            setOnLongClickListener { showAppMenu(a, true); true }
        }
    }

    private fun buildDock() {
        dockBar.removeAllViews()
        val items = dock.mapNotNull { p -> allApps.find { it.pkg == p } }
        val lp = dockBar.layoutParams as LinearLayout.LayoutParams
        if (win) {
            lp.setMargins(0, 0, 0, 0)
            dockBar.background = ColorDrawable(0xE6101820.toInt())
            // the bar itself reaches the screen bottom; the nav-bar inset is padding inside it
            dockBar.setPadding(px(8), px(6), px(14), px(6) + bottomInset)
            dockBar.addView(TextView(this).apply {
                text = "⊞"; textSize = 28f; setTextColor(accent)
                contentDescription = getString(R.string.cd_all_apps)
                gravity = Gravity.CENTER
                minHeight = px(48)
                setPadding(px(10), 0, px(14), 0)
                setOnClickListener { openDrawer(false) }
            })
            items.forEach { dockBar.addView(dockIcon(it, 34), LinearLayout.LayoutParams(px(48), px(48))) }
            dockBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            dockBar.addView(TextClock(this).apply {
                format12Hour = "hh:mm a"; format24Hour = "HH:mm"; textSize = 12f; setTextColor(Color.WHITE)
            })
        } else if (items.isEmpty()) {
            // empty dock: no empty pill, just keep the bottom spacing
            lp.setMargins(px(16), 0, px(16), px(16) + bottomInset)
            dockBar.background = null
            dockBar.setPadding(0, 0, 0, 0)
        } else {
            lp.setMargins(px(16), 0, px(16), px(16) + bottomInset)
            dockBar.background = round(0x44FFFFFF, 24)
            dockBar.setPadding(px(8), px(10), px(8), px(10))
            items.forEach { dockBar.addView(dockIcon(it, 52), LinearLayout.LayoutParams(0, -2, 1f)) }
        }
        dockBar.layoutParams = lp
    }

    // ---------- Drawer ----------
    private fun openDrawer(focus: Boolean) {
        category = -1
        libMode = false
        buildChips()
        search.setText("")
        applyFilter()
        drawer.animate().cancel()
        drawer.alpha = 0f
        drawer.translationY = px(56).toFloat()
        drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).translationY(0f).setDuration(420).setInterpolator(SpringInterpolator()).start()
        animateBlur(90)
        if (focus) {
            search.requestFocus()
            // wait until the drawer is actually shown, otherwise many devices ignore the request
            search.post {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    private fun closeDrawer() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
        if (drawer.visibility != View.VISIBLE) return
        animateBlur(0)
        drawer.animate().cancel()
        drawer.animate().alpha(0f).translationY(px(48).toFloat()).setDuration(160)
            .setInterpolator(DecelerateInterpolator()).withEndAction {
                drawer.visibility = View.GONE
                drawer.alpha = 1f
                drawer.translationY = 0f
            }.start()
    }

    private fun tryStart(i: Intent, opts: Bundle? = null): Boolean = try {
        startActivity(i, opts)
        true
    } catch (e: Exception) {
        Log.w(TAG, "startActivity failed: $i", e)
        false
    }

    private fun safeStart(i: Intent) {
        if (!tryStart(i)) toast(getString(R.string.open_failed))
    }

    // ---------- Launch + app lock ----------
    private fun launch(a: App, src: View? = null) {
        closeDrawer()
        if (freeformOn && freeformSupported()) { launchFreeform(a); return }
        if (a.pkg in locked) requireAuth { launchNow(a, null) } else launchNow(a, src)
    }

    private fun launchNow(a: App, src: View?) {
        val i = packageManager.getLaunchIntentForPackage(a.pkg)
        if (i == null) { toast(getString(R.string.cant_open)); return }
        // the app window grows out of the tapped icon
        val opts = when (animMode) {
            1 -> ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
            2 -> ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle()
            else -> if (src != null && src.width > 0)
                ActivityOptions.makeScaleUpAnimation(src, 0, 0, src.width, src.height).toBundle() else null
        }
        if (tryStart(i, opts)) prefs.edit().putInt("n_${a.pkg}", launchCount(a.pkg) + 1).apply() else toast(getString(R.string.open_failed))
    }

    private fun hasSecureLock() = (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure

    // Fingerprint / face / PIN via the system prompt. This only guards the launcher itself (not recents or notifications).
    // If the phone has no screen lock any more, it lets the action through instead of locking the user out.
    private fun requireAuth(then: () -> Unit) {
        if (!hasSecureLock()) { then(); return }
        if (Build.VERSION.SDK_INT >= 30) biometricAuth(then) else legacyAuth(then)
    }

    @TargetApi(30)
    private fun biometricAuth(then: () -> Unit) {
        try {
            val prompt = BiometricPrompt.Builder(this)
                .setTitle("My Launcher")
                .setSubtitle(getString(R.string.auth_subtitle))
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                .build()
            prompt.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { then() }
            })
        } catch (e: Exception) {
            Log.w(TAG, "biometric prompt failed, using lock-screen prompt", e)
            legacyAuth(then)
        }
    }

    @Suppress("DEPRECATION")
    private fun legacyAuth(then: () -> Unit) {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val i = km.createConfirmDeviceCredentialIntent("My Launcher", getString(R.string.auth_credential))
        if (i == null) { then(); return }
        afterAuth = then
        try {
            startActivityForResult(i, REQ_AUTH)
        } catch (e: Exception) {
            afterAuth = null
            toast(getString(R.string.auth_failed))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CONTACTS && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("contacts", true).apply()
            toast(getString(R.string.contacts_on))
        }
        if (requestCode == REQ_PHOTOS && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("gallery", true).apply()
            toast(getString(R.string.gallery_on))
        }
    }

    // ---------- Widgets (hosted AppWidgets are fully interactive: music controls, to-do lists, toggles) ----------
    private fun restoreWidgets() {
        val all = widgetIds
        val keep = all.filter { awm.getAppWidgetInfo(it) != null }
        for (id in all) if (id !in keep) widgetHost.deleteAppWidgetId(id)
        widgetIds = keep
        layoutWidgets()
    }

    private fun makeWidgetView(id: Int, info: AppWidgetProviderInfo): View? = try {
        widgetHost.createView(this, id, info).also { it.tag = id }
    } catch (e: Exception) {
        Log.w(TAG, "widget view failed: $id", e)
        null
    }

    // List mode: widgets one below the other. Stack mode: one slot, swipe sideways between them.
    private fun layoutWidgets() {
        widgetBox.removeAllViews()
        stack = null; dotsRow = null; stackIds = emptyList()
        val infos = widgetIds.mapNotNull { id -> awm.getAppWidgetInfo(id)?.let { id to it } }
        if (infos.isEmpty()) return
        if (!stackMode || infos.size == 1) {
            for ((id, info) in infos) {
                val v = makeWidgetView(id, info) ?: continue
                widgetBox.addView(v, LinearLayout.LayoutParams(-1, info.minHeight.coerceIn(px(60), px(400))).apply { setMargins(px(20), px(8), px(20), 0) })
            }
            return
        }
        val pageW = resources.displayMetrics.widthPixels
        val h = infos.maxOf { it.second.minHeight }.coerceIn(px(60), px(400))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val ids = ArrayList<Int>()
        for ((id, info) in infos) {
            val v = makeWidgetView(id, info) ?: continue
            row.addView(v, LinearLayout.LayoutParams(pageW - px(40), h).apply { setMargins(px(20), px(8), px(20), 0) })
            ids.add(id)
        }
        if (ids.isEmpty()) return
        val sc = SnapScroll(this)
        sc.pitch = pageW
        sc.pages = ids.size
        sc.addView(row, FrameLayout.LayoutParams(-2, -2))
        sc.onPage = { page, byUser -> updateDots(page); if (byUser) recordWidgetPage(page) }
        stack = sc
        stackIds = ids
        widgetBox.addView(sc, LinearLayout.LayoutParams(-1, -2))
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        dotsRow = dots
        widgetBox.addView(dots, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(4) })
        updateDots(0)
        autoFlip()
    }

    private fun updateDots(page: Int) {
        val d = dotsRow ?: return
        d.removeAllViews()
        for (i in stackIds.indices) {
            d.addView(white(TextView(this).apply {
                text = if (i == page) "●" else "○"; textSize = 10f
                setPadding(px(3), 0, px(3), 0)
            }))
        }
    }

    // 0 night, 1 morning, 2 afternoon, 3 evening
    private fun timeSlot() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) / 6

    // Learns which widget you swipe to at which time of day (stored on the phone only)
    private fun recordWidgetPage(page: Int) {
        val id = stackIds.getOrNull(page) ?: return
        val key = "wu_${timeSlot()}_$id"
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
    }

    // Brings forward the widget you most often use at this time of day
    private fun autoFlip() {
        val sc = stack ?: return
        if (!flipOn) return
        val slot = timeSlot()
        var best = -1
        var bestN = 0
        for ((idx, id) in stackIds.withIndex()) {
            val n = prefs.getInt("wu_${slot}_$id", 0)
            if (n > bestN) { bestN = n; best = idx }
        }
        if (best >= 0) sc.post { sc.goTo(best, false); updateDots(best) }
    }

    private fun pickWidget() {
        val providers = awm.installedProviders.sortedBy { it.loadLabel(packageManager).lowercase() }
        if (providers.isEmpty()) { toast(getString(R.string.no_widgets)); return }
        val names = providers.map { "${it.loadLabel(packageManager)}  •  ${it.provider.packageName}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle(getString(R.string.add_widget))
            .setItems(names) { _, i -> startBind(providers[i]) }
            .show()
    }

    @Suppress("DEPRECATION")
    private fun startBind(p: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        if (awm.bindAppWidgetIdIfAllowed(id, p.provider)) {
            configureOrAdd(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            try {
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                Log.w(TAG, "widget bind failed", e)
                dropPending()
                toast(getString(R.string.widget_failed))
            }
        }
    }

    private fun configureOrAdd(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info != null && info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (e: Exception) {
                Log.w(TAG, "widget configure failed", e)
                addWidget(id)
            }
        } else {
            addWidget(id)
        }
    }

    private fun addWidget(id: Int) {
        pendingWidgetId = -1
        if (awm.getAppWidgetInfo(id) != null) {
            widgetIds = widgetIds + id
            layoutWidgets()
        } else {
            widgetHost.deleteAppWidgetId(id)
            toast(getString(R.string.widget_failed))
        }
    }

    private fun dropPending() {
        if (pendingWidgetId != -1) widgetHost.deleteAppWidgetId(pendingWidgetId)
        pendingWidgetId = -1
    }

    private fun removeWidgetDialog() {
        val ids = widgetIds
        if (ids.isEmpty()) { toast(getString(R.string.no_widgets)); return }
        val names = ids.map { awm.getAppWidgetInfo(it)?.loadLabel(packageManager) ?: getString(R.string.widget_n, it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(getString(R.string.remove_widget_q))
            .setItems(names) { _, i ->
                val id = ids[i]
                widgetHost.deleteAppWidgetId(id)
                widgetIds = widgetIds - id
                layoutWidgets()
            }.show()
    }

    // ---------- Gesture / badge services ----------
    private fun listenerEnabled() =
        Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true

    private fun badgeStatus() = when {
        !listenerEnabled() -> getString(R.string.perm_needed)
        badgesOn -> getString(R.string.on)
        else -> getString(R.string.off)
    }

    private fun toggleBadges() {
        if (!listenerEnabled()) {
            AlertDialog.Builder(this).setTitle(getString(R.string.notif_access_title))
                .setMessage(getString(R.string.notif_access_msg))
                .setPositiveButton(getString(R.string.open_settings)) { _, _ -> safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
            return
        }
        prefs.edit().putBoolean("badges", !badgesOn).apply()
        refreshBadges()
    }

    private fun dtStatus() = when {
        !prefs.getBoolean("dtlock", false) -> getString(R.string.off)
        LauncherAccessibilityService.instance != null -> getString(R.string.on)
        else -> getString(R.string.enable_service)
    }

    private fun toggleDoubleTap() {
        if (Build.VERSION.SDK_INT < 28) { toast(getString(R.string.needs_android9)); return }
        val on = !prefs.getBoolean("dtlock", false)
        prefs.edit().putBoolean("dtlock", on).apply()
        if (on && LauncherAccessibilityService.instance == null) {
            AlertDialog.Builder(this).setTitle(getString(R.string.a11y_title))
                .setMessage(getString(R.string.a11y_msg))
                .setPositiveButton(getString(R.string.open_settings)) { _, _ -> safeStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    // ---------- Menus ----------
    @Suppress("DEPRECATION")
    private fun canUninstall(pkg: String): Boolean = try {
        val f = if (Build.VERSION.SDK_INT >= 33)
            packageManager.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0L)).flags
        else packageManager.getApplicationInfo(pkg, 0).flags
        (f and ApplicationInfo.FLAG_SYSTEM) == 0 || (f and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
    } catch (e: Exception) { true }

    private fun showAppMenu(a: App, fromDock: Boolean) {
        val installed = allApps.map { it.pkg }.toSet()
        val acts = mutableListOf<Pair<String, () -> Unit>>()
        acts.add(getString(R.string.app_info) to {
            safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
        })
        acts.add(getString(R.string.app_split) to { closeDrawer(); pickSplit(a) })
        acts.add(getString(R.string.app_window) to { launchFreeform(a) })
        if (canUninstall(a.pkg)) {
            acts.add(getString(R.string.uninstall) to {
                safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            })
        }
        if (a.pkg in locked) {
            acts.add(getString(R.string.unlock_app) to {
                requireAuth { prefs.edit().putStringSet("locked", locked - a.pkg).apply(); applyPrefs() }
            })
        } else {
            acts.add(getString(R.string.lock_app) to {
                if (!hasSecureLock()) toast(getString(R.string.need_screen_lock))
                else { prefs.edit().putStringSet("locked", locked + a.pkg).apply(); applyPrefs() }
            })
        }
        if (fromDock) {
            acts.add(getString(R.string.remove_from_dock) to { dock = dock - a.pkg; buildDock() })
        } else {
            acts.add(getString(R.string.hide_app) to {
                prefs.edit().putStringSet("hidden", hidden + a.pkg).apply(); applyFilter()
            })
            if (a.pkg !in dock && dock.count { it in installed } < maxDock) {
                acts.add(getString(R.string.add_to_dock) to { dock = (dock.filter { it in installed } + a.pkg).distinct(); buildDock() })
            }
        }
        AlertDialog.Builder(this).setTitle(a.label)
            .setItems(acts.map { it.first }.toTypedArray()) { _, i -> acts[i].second() }
            .show()
    }

    private fun menu(title: String, acts: List<Pair<String, () -> Unit>>) {
        AlertDialog.Builder(this).setTitle(title)
            .setItems(acts.map { it.first }.toTypedArray()) { _, i -> acts[i].second() }
            .show()
    }

    private fun onOff(b: Boolean) = if (b) getString(R.string.on) else getString(R.string.off)

    // ---------- Multi-window & tools ----------
    private var torchOn = false
    private var freeformCount = 0

    private fun freeformSupported() = packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
    private val freeformOn get() = prefs.getBoolean("freeform", false)

    // Global actions (split screen, recents, screenshot ...) go through the accessibility service
    private fun ensureA11y(): Boolean {
        if (LauncherAccessibilityService.instance != null) return true
        AlertDialog.Builder(this).setTitle(getString(R.string.a11y_title))
            .setMessage(getString(R.string.a11y_msg))
            .setPositiveButton(getString(R.string.open_settings)) { _, _ -> safeStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
        return false
    }

    private fun a11yAction(delayMs: Long = 400, f: () -> Boolean) {
        if (!ensureA11y()) return
        ui.postDelayed({ if (!f()) toast(getString(R.string.open_failed)) }, delayMs)
    }

    private fun pickApp(title: String, exclude: String?, onPick: (App) -> Unit) {
        val list = allApps.filter { it.pkg != exclude && it.pkg != packageName }.sortedBy { it.label.lowercase() }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(list.map { it.label }.toTypedArray()) { _, i -> onPick(list[i]) }
            .show()
    }

    private fun pickSplit(first: App? = null) {
        if (!ensureA11y()) return
        if (first != null) {
            pickApp(getString(R.string.mw_pick_second), first.pkg) { b -> splitLaunch(first, b) }
        } else {
            pickApp(getString(R.string.mw_pick_first), null) { a ->
                pickApp(getString(R.string.mw_pick_second), a.pkg) { b -> splitLaunch(a, b) }
            }
        }
    }

    // Opens A, asks the system to dock it (split screen), then opens B in the other half.
    private fun splitLaunch(a: App, b: App) {
        val run = {
            val ia = packageManager.getLaunchIntentForPackage(a.pkg)
            val ib = packageManager.getLaunchIntentForPackage(b.pkg)
            if (ia == null || ib == null) toast(getString(R.string.cant_open))
            else if (!tryStart(ia)) toast(getString(R.string.open_failed))
            else ui.postDelayed({
                if (!LauncherAccessibilityService.splitScreen()) toast(getString(R.string.split_failed))
                else ui.postDelayed({
                    ib.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                    if (!tryStart(ib)) toast(getString(R.string.split_failed))
                }, 900)
            }, 700)
        }
        if (a.pkg in locked || b.pkg in locked) requireAuth { run() } else run()
    }

    // Freeform (resizable window) launch. Works only where the phone has freeform mode enabled.
    private fun freeformOptions(): Bundle? = try {
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.78f).toInt()
        val h = (dm.heightPixels * 0.55f).toInt()
        val step = px(36) * (freeformCount % 6)
        val left = px(16) + step
        val top = px(70) + step
        val o = ActivityOptions.makeBasic()
        o.setLaunchBounds(Rect(left, top, left + w, top + h))
        try {
            ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(o, 5)
        } catch (e: Throwable) { /* hidden API; launch bounds alone is enough where freeform is on */ }
        freeformCount++
        o.toBundle()
    } catch (e: Exception) { null }

    private fun launchFreeform(a: App) {
        closeDrawer()
        if (!freeformSupported()) { freeformHelp(); return }
        val run = {
            val i = packageManager.getLaunchIntentForPackage(a.pkg)
            if (i == null) toast(getString(R.string.cant_open))
            else {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                if (!tryStart(i, freeformOptions())) toast(getString(R.string.open_failed))
            }
        }
        if (a.pkg in locked) requireAuth { run() } else run()
    }

    private fun freeformHelp() {
        AlertDialog.Builder(this).setTitle(getString(R.string.freeform_help_title))
            .setMessage(getString(R.string.freeform_help_msg))
            .setPositiveButton(getString(R.string.open_dev_options)) { _, _ -> safeStart(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun toggleFreeform() {
        if (!freeformSupported()) { freeformHelp(); return }
        prefs.edit().putBoolean("freeform", !freeformOn).apply()
    }

    // Floating calculator / notes / browser drawn over other apps
    private fun openFloating(type: String) {
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this).setTitle(getString(R.string.overlay_title))
                .setMessage(getString(R.string.overlay_msg))
                .setPositiveButton(getString(R.string.open_settings)) { _, _ ->
                    safeStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
            return
        }
        try { FloatingWindowService.open(this, type) } catch (e: Exception) {
            Log.w(TAG, "floating window failed", e)
            toast(getString(R.string.open_failed))
        }
    }

    private fun closeFloating() {
        if (FloatingWindowService.running) FloatingWindowService.closeAll(this)
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING) == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK
            }
            if (id == null) { toast(getString(R.string.torch_failed)); return }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (e: Exception) {
            torchOn = false
            Log.w(TAG, "torch failed", e)
            toast(getString(R.string.torch_failed))
        }
    }

    // Typing "calc", "notes", "torch", "split", "screenshot" ... in the search box shows a shortcut row
    private fun toolRows(q: String): List<Pair<String, () -> Unit>> {
        val t = q.trim().lowercase()
        if (t.length < 2) return emptyList()
        val tools: List<Pair<List<String>, Pair<String, () -> Unit>>> = listOf(
            listOf("calc", "calculator", "ক্যালকুলেটর") to (getString(R.string.mw_float_calc) to { openFloating(FloatingWindowService.TYPE_CALC) }),
            listOf("notes", "note", "নোট") to (getString(R.string.mw_float_notes) to { openFloating(FloatingWindowService.TYPE_NOTES) }),
            listOf("browser", "ব্রাউজার") to (getString(R.string.mw_float_browser) to { openFloating(FloatingWindowService.TYPE_BROWSER) }),
            listOf("torch", "flashlight", "light", "টর্চ") to (getString(R.string.mw_torch) to { toggleTorch() }),
            listOf("split", "স্প্লিট") to (getString(R.string.mw_split) to { pickSplit() }),
            listOf("screenshot", "স্ক্রিনশট") to (getString(R.string.mw_screenshot) to { a11yAction { LauncherAccessibilityService.screenshot() } }),
            listOf("recents", "recent", "রিসেন্ট") to (getString(R.string.mw_recents) to { a11yAction { LauncherAccessibilityService.recents() } })
        )
        return tools.filter { (keys, _) -> keys.any { it.startsWith(t) } }.map { it.second }
    }

    private fun multiMenu() = menu(getString(R.string.multi), listOf(
        getString(R.string.mw_split) to { pickSplit() },
        getString(R.string.f_freeform, if (!freeformSupported()) getString(R.string.freeform_unsupported) else onOff(freeformOn)) to { toggleFreeform() },
        getString(R.string.mw_float_calc) to { openFloating(FloatingWindowService.TYPE_CALC) },
        getString(R.string.mw_float_notes) to { openFloating(FloatingWindowService.TYPE_NOTES) },
        getString(R.string.mw_float_browser) to { openFloating(FloatingWindowService.TYPE_BROWSER) },
        getString(R.string.mw_close_floating) to { closeFloating() },
        getString(R.string.mw_recents) to { a11yAction { LauncherAccessibilityService.recents() } },
        getString(R.string.mw_screenshot) to { a11yAction(700) { LauncherAccessibilityService.screenshot() } },
        getString(R.string.mw_torch) to { toggleTorch() },
        getString(R.string.mw_power) to { a11yAction { LauncherAccessibilityService.powerMenu() } },
        getString(R.string.mw_quick) to { a11yAction { LauncherAccessibilityService.quickSettings() } }
    ))

    // ---------- Simple mode + settings backup ----------
    private fun toggleSimple() {
        val e = prefs.edit()
        if (!simpleOn) {
            e.putInt("sp_cols", cols).putInt("sp_icon", iconDp).putBoolean("sp_labels", labelsOn).putBoolean("sp_stack", stackMode)
            e.putBoolean("simple", true).putInt("cols", 3).putInt("icon", 72).putBoolean("labels", true).putBoolean("stack", false)
        } else {
            e.putInt("cols", prefs.getInt("sp_cols", 4)).putInt("icon", prefs.getInt("sp_icon", 48))
                .putBoolean("labels", prefs.getBoolean("sp_labels", true)).putBoolean("stack", prefs.getBoolean("sp_stack", false))
                .putBoolean("simple", false)
        }
        e.apply()
        applyPrefs()
        layoutWidgets()
    }

    @Suppress("DEPRECATION")
    private fun exportSettings() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/json").putExtra(Intent.EXTRA_TITLE, "my-launcher-backup.json")
        try { startActivityForResult(i, REQ_EXPORT) } catch (e: Exception) { toast(getString(R.string.backup_failed)) }
    }

    @Suppress("DEPRECATION")
    private fun importSettings() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        try { startActivityForResult(i, REQ_IMPORT) } catch (e: Exception) { toast(getString(R.string.restore_failed)) }
    }

    private fun writeBackup(uri: Uri) {
        try {
            val root = org.json.JSONObject()
            for ((k, v) in prefs.all) {
                if (k == "widgets") continue // widget ids only make sense on this phone
                val o = org.json.JSONObject()
                when (v) {
                    is Boolean -> o.put("t", "b").put("v", v)
                    is Int -> o.put("t", "i").put("v", v)
                    is Long -> o.put("t", "l").put("v", v)
                    is Float -> o.put("t", "f").put("v", v.toDouble())
                    is String -> o.put("t", "s").put("v", v)
                    is Set<*> -> o.put("t", "set").put("v", org.json.JSONArray(v.map { it.toString() }))
                    else -> continue
                }
                root.put(k, o)
            }
            val out = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("no stream")
            out.use { it.write(root.toString(2).toByteArray()) }
            toast(getString(R.string.backup_done))
        } catch (e: Exception) {
            Log.w(TAG, "backup failed", e)
            toast(getString(R.string.backup_failed))
        }
    }

    private fun readBackup(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: throw java.io.IOException("no stream")
            val root = org.json.JSONObject(input.use { String(it.readBytes()) })
            val e = prefs.edit()
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                if (k == "widgets") continue
                val o = root.getJSONObject(k)
                when (o.getString("t")) {
                    "b" -> e.putBoolean(k, o.getBoolean("v"))
                    "i" -> e.putInt(k, o.getInt("v"))
                    "l" -> e.putLong(k, o.getLong("v"))
                    "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                    "s" -> e.putString(k, o.getString("v"))
                    "set" -> {
                        val a = o.getJSONArray("v")
                        e.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                    }
                }
            }
            e.apply()
            toast(getString(R.string.restore_done))
            recreate()
        } catch (ex: Exception) {
            Log.w(TAG, "restore failed", ex)
            toast(getString(R.string.restore_failed))
        }
    }

    private fun showSettings() = menu(getString(R.string.settings), listOf(
        getString(R.string.m_appearance) to { appearanceMenu() },
        getString(R.string.m_widgets) to { widgetMenu() },
        getString(R.string.m_smart) to { smartMenu() },
        getString(R.string.m_multi) to { multiMenu() },
        getString(R.string.m_privacy) to { privacyMenu() }
    ))

    private fun appearanceMenu() = menu(getString(R.string.appearance), listOf(
        getString(R.string.f_columns, cols) to {
            prefs.edit().putInt("cols", if (cols >= 5) 3 else cols + 1).apply(); applyPrefs()
        },
        getString(R.string.f_icon_size, iconDp) to {
            prefs.edit().putInt("icon", when (iconDp) { 40 -> 48; 48 -> 56; else -> 40 }).apply(); applyPrefs()
        },
        getString(R.string.f_style, getString(if (win) R.string.style_taskbar else R.string.style_dock)) to {
            prefs.edit().putBoolean("win", !win).apply(); applyPrefs()
        },
        getString(R.string.f_drawer_theme, getString(if (dark) R.string.theme_dark else R.string.theme_light)) to {
            prefs.edit().putBoolean("dark", !dark).apply(); applyTheme()
        },
        getString(R.string.f_accent, getString(ACCENT_NAMES[prefs.getInt("accent", 0).coerceIn(0, ACCENTS.size - 1)])) to {
            prefs.edit().putInt("accent", (prefs.getInt("accent", 0) + 1) % ACCENTS.size).apply(); applyTheme()
        },
        getString(R.string.f_glass, if (Build.VERSION.SDK_INT < 31) getString(R.string.needs_android12) else onOff(prefs.getBoolean("glass", true))) to {
            prefs.edit().putBoolean("glass", !prefs.getBoolean("glass", true)).apply(); applyTheme()
        },
        getString(R.string.f_icon_pack, iconPackName()) to { pickIconPack() },
        getString(R.string.f_sort, getString(when (sortMode) { 1 -> R.string.sort_freq; 2 -> R.string.sort_new; else -> R.string.sort_az })) to {
            prefs.edit().putInt("sort", (sortMode + 1) % 3).apply(); applyFilter()
        },
        getString(R.string.f_shape, getString(when (shapeMode) { 1 -> R.string.shape_circle; 2 -> R.string.shape_rounded; 3 -> R.string.shape_square; else -> R.string.shape_default })) to {
            prefs.edit().putInt("shape", (shapeMode + 1) % 4).apply(); applyPrefs()
        },
        getString(R.string.f_anim, getString(when (animMode) { 1 -> R.string.anim_fade; 2 -> R.string.anim_none; else -> R.string.anim_zoom })) to {
            prefs.edit().putInt("anim", (animMode + 1) % 3).apply()
        },
        getString(R.string.f_badge_style, getString(if (badgeDot) R.string.badge_dot else R.string.badge_number)) to {
            prefs.edit().putBoolean("badgedot", !badgeDot).apply(); refreshBadges()
        },
        getString(R.string.f_search_bar, onOff(showSearchBar)) to {
            prefs.edit().putBoolean("showsearch", !showSearchBar).apply(); applyPrefs()
        },
        getString(R.string.f_rotation, onOff(rotateOn)) to {
            prefs.edit().putBoolean("rotate", !rotateOn).apply(); applyPrefs()
        },
        getString(R.string.f_simple, onOff(simpleOn)) to { toggleSimple() },
        getString(R.string.f_labels, getString(if (labelsOn) R.string.labels_show else R.string.labels_hide)) to {
            prefs.edit().putBoolean("labels", !labelsOn).apply(); applyPrefs()
        },
        getString(R.string.f_parallax, onOff(parallaxOn)) to { toggleParallax() }
    ))

    private fun widgetMenu() = menu(getString(R.string.widgets), listOf(
        getString(R.string.add_widget) to { pickWidget() },
        getString(R.string.f_remove_widgets, widgetIds.size) to { removeWidgetDialog() },
        getString(R.string.f_layout, getString(if (stackMode) R.string.layout_stack else R.string.layout_list)) to {
            prefs.edit().putBoolean("stack", !stackMode).apply(); layoutWidgets()
        },
        getString(R.string.f_flip, onOff(flipOn)) to {
            prefs.edit().putBoolean("flip", !flipOn).apply(); autoFlip()
        }
    ))

    // ---------- Gallery photo search (by file name or album name) ----------
    private fun photoPermission() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE

    private val galleryOn get() = prefs.getBoolean("gallery", false) &&
        checkSelfPermission(photoPermission()) == PackageManager.PERMISSION_GRANTED

    private fun queryPhotos(name: String): List<Photo> {
        val out = ArrayList<Photo>()
        if (checkSelfPermission(photoPermission()) != PackageManager.PERMISSION_GRANTED) return out
        try {
            val nameCol = MediaStore.Images.Media.DISPLAY_NAME
            val bucketCol = MediaStore.Images.Media.BUCKET_DISPLAY_NAME
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID, nameCol),
                "$nameCol LIKE ? OR $bucketCol LIKE ?", arrayOf("%$name%", "%$name%"),
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 3) {
                    val n = c.getString(1) ?: continue
                    out.add(Photo(n, ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0))))
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "photo search failed", e)
        }
        return out
    }

    private fun openPhoto(p: Photo) = safeStart(
        Intent(Intent.ACTION_VIEW).setDataAndType(p.uri, "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    )

    private fun galleryStatus() =
        if (checkSelfPermission(photoPermission()) != PackageManager.PERMISSION_GRANTED) getString(R.string.perm_needed)
        else onOff(prefs.getBoolean("gallery", false))

    private fun toggleGallery() {
        if (checkSelfPermission(photoPermission()) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(photoPermission()), REQ_PHOTOS)
            return
        }
        prefs.edit().putBoolean("gallery", !prefs.getBoolean("gallery", false)).apply()
    }

    private fun contactsStatus() =
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) getString(R.string.perm_needed)
        else onOff(prefs.getBoolean("contacts", false))

    private fun toggleContacts() {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS)
            return
        }
        prefs.edit().putBoolean("contacts", !prefs.getBoolean("contacts", false)).apply()
    }

    private fun smartMenu() = menu(getString(R.string.smart), listOf(
        getString(R.string.f_smart, onOff(smart)) to {
            prefs.edit().putBoolean("smart", !smart).apply(); applyFilter()
        },
        getString(R.string.f_pill, onOff(pillOn)) to {
            prefs.edit().putBoolean("pill", !pillOn).apply(); updatePill()
        },
        getString(R.string.f_contacts, contactsStatus()) to { toggleContacts() },
        getString(R.string.f_gallery, galleryStatus()) to { toggleGallery() },
        getString(R.string.f_badges, badgeStatus()) to { toggleBadges() }
    ))

    private fun privacyMenu() = menu(getString(R.string.privacy), listOf(
        getString(R.string.backup_export) to { exportSettings() },
        getString(R.string.backup_import) to { importSettings() },
        getString(R.string.f_hidden, hidden.size) to { showHidden() },
        getString(R.string.f_dtlock, dtStatus()) to { toggleDoubleTap() },
        getString(R.string.change_wallpaper) to {
            safeStart(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), getString(R.string.wallpaper)))
        }
    ))

    // The hidden list needs the phone's screen lock (when one is set)
    private fun showHidden() = requireAuth { showHiddenList() }

    private fun showHiddenList() {
        val hs = allApps.filter { it.pkg in hidden }
        if (hs.isEmpty()) { toast(getString(R.string.no_hidden)); return }
        AlertDialog.Builder(this).setTitle(getString(R.string.tap_to_restore))
            .setItems(hs.map { it.label }.toTypedArray()) { _, i ->
                prefs.edit().putStringSet("hidden", hidden - hs[i].pkg).apply(); applyFilter()
            }.show()
    }

    // ---------- Grid adapter ----------
    private inner class AppAdapter : BaseAdapter() {
        var items: List<App> = emptyList()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup): View {
            val cell = (v?.tag as? Cell) ?: newCell().also { it.root.tag = it }
            bindCell(cell, items[p], px(iconDp), true)
            return cell.root
        }
    }
}
