package com.example.launcher

import android.app.Notification
import android.app.PendingIntent
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Counts active (non-ongoing, non-summary) notifications per app for icon badges, and collects
 * "live" ongoing ones (calls, music, timers, navigation, delivery/ride progress) for the floating pill.
 */
class BadgeService : NotificationListenerService() {

    /** An ongoing notification worth showing in the pill. */
    class Live(val pkg: String, val title: String, val text: String, val category: String, val intent: PendingIntent?)

    override fun onListenerConnected() = refresh()

    override fun onListenerDisconnected() {
        counts = emptyMap()
        live = emptyList()
        notifyChanged()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    private fun refresh() {
        val m = HashMap<String, Int>()
        val l = ArrayList<Live>()
        try {
            activeNotifications?.forEach { n ->
                val nt = n.notification
                val summary = (nt.flags and Notification.FLAG_GROUP_SUMMARY) != 0
                if (n.isOngoing) {
                    val cat = nt.category
                    if (cat != null && cat in LIVE_CATEGORIES) {
                        val title = nt.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                        val text = nt.extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
                        l.add(Live(n.packageName, title, text, cat, nt.contentIntent))
                    }
                    return@forEach
                }
                if (summary) return@forEach
                m[n.packageName] = (m[n.packageName] ?: 0) + 1
            }
        } catch (e: Exception) {
            // listener not ready yet; keep the old data
            return
        }
        // calls first, then the rest in the order they arrived
        l.sortBy { if (it.category == "call") 0 else 1 }
        counts = m
        live = l
        notifyChanged()
    }

    companion object {
        private val LIVE_CATEGORIES = setOf("call", "transport", "progress", "navigation", "stopwatch")
        @Volatile var counts: Map<String, Int> = emptyMap()
        @Volatile var live: List<Live> = emptyList()
        @Volatile var listener: (() -> Unit)? = null
        private val ui = Handler(Looper.getMainLooper())
        private fun notifyChanged() { ui.post { listener?.invoke() } }
    }
}
