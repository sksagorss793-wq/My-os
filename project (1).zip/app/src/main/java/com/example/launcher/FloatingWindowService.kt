package com.example.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.net.URLEncoder

/**
 * Floating mini windows drawn over other apps: calculator, notes and a small browser.
 * Each window can be dragged by its title bar, resized with the corner handle, minimised and closed.
 * (Android does not let a launcher put other apps' activities inside its own floating windows.)
 */
class FloatingWindowService : Service() {

    companion object {
        private const val TAG = "FloatingWindows"
        private const val CHANNEL = "floating_windows"
        const val ACTION_CLOSE_ALL = "com.example.launcher.CLOSE_FLOATING"
        const val EXTRA_TYPE = "type"
        const val TYPE_CALC = "calc"
        const val TYPE_NOTES = "notes"
        const val TYPE_BROWSER = "browser"
        @Volatile var running = false

        fun open(ctx: Context, type: String) {
            val i = Intent(ctx, FloatingWindowService::class.java).putExtra(EXTRA_TYPE, type)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun closeAll(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingWindowService::class.java).setAction(ACTION_CLOSE_ALL))
        }
    }

    private class Win(val root: View, val lp: WindowManager.LayoutParams)

    private lateinit var wm: WindowManager
    private val wins = ArrayList<Win>()
    private val prefs by lazy { getSharedPreferences("floating", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        running = true
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE_ALL) {
            closeEverything()
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            when (intent?.getStringExtra(EXTRA_TYPE)) {
                TYPE_CALC -> addWindow(getString(R.string.float_calc), 260, 0, false, calcBody())
                TYPE_NOTES -> addWindow(getString(R.string.float_notes), 280, 300, true, notesBody())
                TYPE_BROWSER -> addWindow(getString(R.string.float_browser), 320, 420, true, browserBody())
            }
        } catch (e: Exception) {
            Log.w(TAG, "could not open window", e)
        }
        if (wins.isEmpty()) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        closeEverything()
        running = false
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.float_channel), NotificationManager.IMPORTANCE_LOW))
        }
        val close = PendingIntent.getService(
            this, 0, Intent(this, FloatingWindowService::class.java).setAction(ACTION_CLOSE_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle(getString(R.string.float_notif_title))
            .setContentText(getString(R.string.float_notif_text))
            .setContentIntent(close)
            .setOngoing(true)
        startForeground(77, b.build())
    }

    private fun closeEverything() {
        for (w in wins.toList()) removeWindow(w, false)
        wins.clear()
    }

    private fun removeWindow(w: Win, stopIfEmpty: Boolean = true) {
        try { wm.removeView(w.root) } catch (e: Exception) { Log.w(TAG, "remove failed", e) }
        wins.remove(w)
        if (stopIfEmpty && wins.isEmpty()) stopSelf()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    // ---------- window frame ----------
    private fun addWindow(title: String, wDp: Int, hDp: Int, focusableBody: Boolean, body: View) {
        val dm = resources.displayMetrics
        val width = minOf(dp(wDp), (dm.widthPixels * 0.92f).toInt())
        val height = if (hDp == 0) WindowManager.LayoutParams.WRAP_CONTENT else minOf(dp(hDp), (dm.heightPixels * 0.8f).toInt())
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(24) + wins.size * dp(28)
        lp.y = dp(90) + wins.size * dp(28)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        val frame = object : FrameLayout(this) {
            // BACK closes the keyboard and gives key focus back to the app below
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    hideIme(this)
                    setFocusable(this, lp, false)
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        frame.background = round(0xF2202124.toInt(), 14)
        frame.setPadding(dp(1), dp(1), dp(1), dp(1))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = round(0xFF3C4043.toInt(), 13)
            setPadding(dp(12), dp(4), dp(4), dp(4))
        }
        val titleView = TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 14f; maxLines = 1
        }
        bar.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
        val content = FrameLayout(this).apply { addView(body, FrameLayout.LayoutParams(-1, -1)) }
        var minimized = false
        val minBtn = barButton("–") {
            minimized = !minimized
            content.visibility = if (minimized) View.GONE else View.VISIBLE
            if (minimized) { lp.height = WindowManager.LayoutParams.WRAP_CONTENT } else if (hDp != 0) {
                lp.height = minOf(dp(hDp), (resources.displayMetrics.heightPixels * 0.8f).toInt())
            }
            safeUpdate(frame, lp)
        }
        val win = Win(frame, lp)
        val closeBtn = barButton("✕") { removeWindow(win) }
        bar.addView(minBtn, LinearLayout.LayoutParams(dp(40), dp(36)))
        bar.addView(closeBtn, LinearLayout.LayoutParams(dp(40), dp(36)))
        col.addView(bar, LinearLayout.LayoutParams(-1, -2))
        col.addView(content, LinearLayout.LayoutParams(-1, if (hDp == 0) -2 else 0, if (hDp == 0) 0f else 1f))
        frame.addView(col, FrameLayout.LayoutParams(-1, if (hDp == 0) -2 else -1))

        // drag by the title bar
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; bringToFront(win) }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    safeUpdate(frame, lp)
                }
            }
            true
        }

        // resize with the bottom-right handle
        if (hDp != 0) {
            val handle = TextView(this).apply {
                text = "◢"; setTextColor(0xFF9AA0A6.toInt()); textSize = 16f; gravity = Gravity.CENTER
            }
            var rw = 0; var rh = 0; var rx = 0f; var ry = 0f
            handle.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; rw = lp.width; rh = lp.height }
                    MotionEvent.ACTION_MOVE -> {
                        lp.width = (rw + (e.rawX - rx)).toInt().coerceIn(dp(180), resources.displayMetrics.widthPixels)
                        lp.height = (rh + (e.rawY - ry)).toInt().coerceIn(dp(140), resources.displayMetrics.heightPixels)
                        safeUpdate(frame, lp)
                    }
                }
                true
            }
            frame.addView(handle, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.BOTTOM or Gravity.END))
        }

        if (focusableBody) {
            // tapping a text field makes the window focusable so the keyboard can type into it
            attachFocusHandling(body, frame, lp)
        }
        wm.addView(frame, lp)
        wins.add(win)
    }

    private fun attachFocusHandling(v: View, frame: View, lp: WindowManager.LayoutParams) {
        if (v is EditText) {
            v.setOnTouchListener { view, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                    setFocusable(frame, lp, true)
                    view.requestFocus()
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(view, 0)
                }
                false
            }
        } else if (v is android.view.ViewGroup) {
            for (k in 0 until v.childCount) attachFocusHandling(v.getChildAt(k), frame, lp)
        }
    }

    private fun setFocusable(frame: View, lp: WindowManager.LayoutParams, on: Boolean) {
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        safeUpdate(frame, lp)
    }

    private fun hideIme(v: View) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) { Log.w(TAG, "update failed", e) }
    }

    private fun bringToFront(w: Win) {
        if (wins.lastOrNull() === w) return
        try {
            wm.removeView(w.root); wm.addView(w.root, w.lp)
            wins.remove(w); wins.add(w)
        } catch (e: Exception) { Log.w(TAG, "front failed", e) }
    }

    private fun barButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
        setOnClickListener { onClick() }
    }

    // ---------- calculator ----------
    private fun calcBody(): View {
        var cur = "0"          // number being typed
        var acc = 0.0          // running value
        var op = ""            // pending operator
        var fresh = true       // next digit starts a new number
        val display = TextView(this).apply {
            text = "0"; setTextColor(Color.WHITE); textSize = 30f; gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8)); maxLines = 1
        }
        fun fmt(d: Double): String {
            if (d.isNaN() || d.isInfinite()) return "Error"
            return if (d == Math.rint(d) && Math.abs(d) < 1e12) d.toLong().toString()
            else java.math.BigDecimal(d).round(java.math.MathContext(10)).stripTrailingZeros().toPlainString()
        }
        fun apply(): Double {
            val b = cur.toDoubleOrNull() ?: 0.0
            return when (op) { "+" -> acc + b; "−" -> acc - b; "×" -> acc * b; "÷" -> if (b == 0.0) Double.NaN else acc / b; else -> b }
        }
        fun press(k: String) {
            when (k) {
                in "0123456789" -> { cur = if (fresh || cur == "0") k else cur + k; fresh = false }
                "." -> { if (fresh) { cur = "0."; fresh = false } else if (!cur.contains('.')) cur += "." }
                "C" -> { cur = "0"; acc = 0.0; op = ""; fresh = true }
                "⌫" -> { if (!fresh && cur.length > 1) cur = cur.dropLast(1) else { cur = "0"; fresh = true } }
                "±" -> { cur = if (cur.startsWith("-")) cur.drop(1) else if (cur != "0") "-$cur" else cur }
                "%" -> { cur = fmt((cur.toDoubleOrNull() ?: 0.0) / 100.0); fresh = false }
                "=" -> { if (op.isNotEmpty()) { val r = apply(); cur = fmt(r); acc = if (r.isNaN()) 0.0 else r; op = ""; fresh = true } }
                else -> { // + − × ÷
                    if (op.isNotEmpty() && !fresh) { val r = apply(); acc = if (r.isNaN()) 0.0 else r; cur = fmt(r) }
                    else acc = cur.toDoubleOrNull() ?: 0.0
                    op = k; fresh = true
                }
            }
            display.text = cur
        }
        val keys = listOf("C", "⌫", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "±", "0", ".", "=")
        val grid = GridLayout(this).apply { columnCount = 4; setPadding(dp(6), 0, dp(6), dp(6)) }
        for (k in keys) {
            val isOp = k in listOf("÷", "×", "−", "+", "=")
            val b = Button(this).apply {
                text = k; textSize = 18f; setTextColor(Color.WHITE); isAllCaps = false
                background = round(if (isOp) 0xFF4DA3FF.toInt() else 0xFF3C4043.toInt(), 10)
                setOnClickListener { press(k) }
            }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0; lp.height = dp(48); lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            grid.addView(b, lp)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(display, LinearLayout.LayoutParams(-1, -2))
            addView(grid, LinearLayout.LayoutParams(-1, -2))
        }
    }

    // ---------- notes ----------
    private fun notesBody(): View {
        val et = EditText(this).apply {
            setText(prefs.getString("notes", "") ?: "")
            hint = getString(R.string.float_notes_hint)
            setTextColor(Color.WHITE); setHintTextColor(0xFF9AA0A6.toInt()); textSize = 15f
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = null
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    prefs.edit().putString("notes", s?.toString() ?: "").apply()
                }
            })
        }
        return et
    }

    // ---------- browser ----------
    private fun browserBody(): View {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        val url = EditText(this).apply {
            hint = getString(R.string.float_url_hint)
            setTextColor(Color.WHITE); setHintTextColor(0xFF9AA0A6.toInt()); textSize = 14f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            background = round(0xFF3C4043.toInt(), 10)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        fun go() {
            val t = url.text.toString().trim()
            if (t.isEmpty()) return
            val target = if (!t.contains(' ') && t.contains('.')) (if (t.startsWith("http")) t else "https://$t")
            else "https://www.google.com/search?q=" + URLEncoder.encode(t, "UTF-8")
            web.loadUrl(target)
            hideIme(url)
        }
        url.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER)) { go(); true } else false
        }
        web.loadUrl("https://www.google.com")
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(url, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
        col.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }
}
